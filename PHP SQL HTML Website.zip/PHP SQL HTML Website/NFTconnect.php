<?php 

$con = mysqli_connect('db154.pair.com', '1032364_3', 'NikeFactoryTown', 'mikemitch4_NikeFactoryTown');


?> 