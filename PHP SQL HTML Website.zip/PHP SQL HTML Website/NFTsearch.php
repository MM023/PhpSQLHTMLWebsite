<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : EarthyBlue 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20140215

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nike Factory Town</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900|Quicksand:400,700|Questrial" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="header-wrapper">
    <div id="header" class="container">
        <div id="logo">
            <h1><a href="#">Nike Factory Town</a></h1>
            <div id="menu">
                <ul>
                    <li><a href="NFThome.html" accesskey="1" title="">Homepage</a></li>
                    <li><a href="NFTinventory.html" accesskey="2" title="">Inventory</a></li> 
                    <li ><a href="NFTorder.php" accesskey="3" title="">Order Form</a></li>
                    <li><a href="NFTcontact.php" accesskey="4" title="">Contact Us</a></li> 
                    <li><a href="NFTadminlogin.php" accesskey="5" title="">Admin Login</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="page-wrapper">
    <div id="welcome" class="container">
        <div class="title">
            <h2>Search Previous Orders by First or Last Name</h2>
        </div>  

<center>

<?php 
session_start(); 
require 'NFTconnect2.php';   

?>


<form action="" method="GET">
		<input type="text" name="query" />
		<input type="submit" value="Search" name="searchform" />
</form>


<?php



if(isset($_GET['searchform'])) { 
$query = $_GET['query'];

$result = mysqli_query($con, "SELECT `Id`,`fname`, `lname`, `Email`, `Phone Number`, `Product`, `Size`, `Quantity`, `Price` FROM `Inventory`
			WHERE (`fname` LIKE '%".$query."%') OR (`lname` LIKE '%".$query."%')") or die(mysqli_error()); 
 

if ($result->num_rows > 0) { 
while($row = $result->fetch_assoc()) { 

 echo "<tr>"; 

echo "<table border='1'>
<tr>
<th>Id</th>
<th>First Name</th>
<th>Last Name</th> 
<th>Email</th>
<th>Phone Number</th>  
<th>Product</th>  
<th>Size</th> 
<th>Quantity</th> 
<th>Price</th>  
</tr>";





        echo "<tr>"; 
        echo "<td>{$row['Id']}</td>";
        echo "<td>{$row['fname']}</td>";
        echo "<td>{$row['lname']}</td>"; 
        echo "<td>{$row['Email']}</td>";
        echo "<td>{$row['Phone Number']}</td>"; 
        echo "<td>{$row['Product']}</td>";
        echo "<td>{$row['Size']}</td>"; 
        echo "<td>{$row['Quantity']}</td>";
        echo "<td>{$row['Price']}.00</td>";  
echo "</tr>";
    } 
       echo "</table>";
} else {
     echo "0 results";
}

}

?>


</div>

</body>
</html>



























</body>
</html> 