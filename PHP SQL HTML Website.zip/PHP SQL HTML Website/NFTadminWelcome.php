<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : EarthyBlue 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20140215

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nike Factory Town</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900|Quicksand:400,700|Questrial" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="header-wrapper">
    <div id="header" class="container">
        <div id="logo">
            <h1><a href="#">Nike Factory Town</a></h1>
            <div id="menu">
                <ul>
                    <li><a href="NFThome.html" accesskey="1" title="">Homepage</a></li>
                    <li><a href="NFTinventory.html" accesskey="2" title="">Inventory</a></li> 
                    <li ><a href="NFTorder.php" accesskey="3" title="">Order Form</a></li>
                    <li><a href="NFTcontact.php" accesskey="4" title="">Contact Us</a></li> 
                    <li class="active"><a href="NFTadminlogin.php" accesskey="5" title="">Admin Login</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="page-wrapper">
    <div id="welcome" class="container">
        <div class="title">
            <h2>Login Successful! Welcome Admin!</h2>  

<center>

<p><a href ="NFTsearch.php">Search the Database for Orders</a></p>
        </div>  


</center>
<center>


<?php 
session_start(); 
require 'NFTconnect2.php';   

$epr=''; 
$msg=''; 

if(isset($_GET['epr'])) 
    $epr=$_GET['epr']; 

  if($epr=='delete'){  
            $fname= $_GET['fname'];  
            $id = $_GET['Id'];
            $delete=mysqli_query($con, "DELETE FROM `Inventory` WHERE Id='$id'"); 
            if($delete) 
                header("location: NFTadminWelcome.php");
            else 
                $msg= 'Error: '. mysqli_error($con);
            }  
 
 if($epr=='update'){   
 $id = $_GET['Id'];
$result = mysqli_query($con, "SELECT * FROM `Inventory` WHERE `Id` = '$id'  ");
$records = mysqli_query($con, $result);

while($row = $result->fetch_assoc()) { 
echo "<form action='' method='post'>
<table>
<tr>
<th>Id</th> 
<td><input type='text' name='Id' value='".$row['Id']."'> </td>
</tr> 

<tr>
<th>First Name</th> 
<td><input type='text' name='FirstName1' value='".$row['fname']."'> </td>
</tr> 

<tr> 
<th>Last Name</th>  
<td><input type='text' name='LastName1' value='".$row['lname']."'></td>
</tr> 

<tr> 
<th>Email</th>
<td><input type='text' name='Email1' value='".$row['Email']."'></td>
</tr>

<tr> 
<th>Phone Number</th>   
<td><input type='text' name='Phone1' value='".$row['Phone Number']."'></td>
</tr> 

<tr> 
<th>Product</th>  
<td><input list='products' name='products' value='".$row['Product']."'>
  <datalist id='products'>
    <option value='NIKE AIR ZOOM PEGASUS 33'>
    <option value='NIKE LUNARRACER+ 3'>
    <option value='NIKE LUNAREPIC LOW FLYKNIT'>
    <option value='LEBRON XIII LOW'>
    <option value='NIKE TECH HYPERMESH WINDRUNNER'> 
    <option value='USAB NIKE REPLICA'>
    <option value='NIKE WINDRUNNER'>
    <option value='NIKE SB DRI-FIT STRIPE SUNDAY'>
    <option value='NIKE TECH FLEECE HERO FLASH'>
    <option value='NIKE PRO COOL'> 
    <option value='GARMIN FORERUNNER 235 GPS'>
    <option value='TOMTOM SPARK CARDIO + MUSIC '>  
   </datalist></td>
</tr>   

<tr>
<th>Size</th>   
<td><input list='Size1' name='Size1' value='".$row['Size']."'>
  <datalist id='Size1'>
    <option value='Small'>
    <option value='Medium'>
    <option value='Large'>
    <option value='8'>
    <option value='8.5'> 
    <option value='9'>
    <option value='9.5'>
    <option value='10'>
    <option value='10.5'>
    <option value='11'> 
    <option value='11.5'>
    <option value='12'>  
   </datalist> </td>
</tr> 

<tr> 
<th>Quantity</th>  
<td><input list ='Quantity1' name='Quantity1' value='".$row['Quantity']."'>
<datalist id='Quantity1'>  
<option value='1'>
</datalist></td>
</tr>

<tr>
<th>Price</th>   
<td><input type='text' name='Price1' value='".$row['Price']."'></td>  
</tr>

<tr> 
<td></td> 
<td><input type='submit' name='UpdateOrder' value='Update'></td>";
     } 
   echo "</table> 
       </form>";
}  

if(isset($_POST['UpdateOrder'])) {  

            $id = $_POST['Id'];
            $FirstName1 = $_POST['FirstName1']; 
            $LastName1 = $_POST['LastName1'];  
            $Email1 = $_POST['Email1'];  
            $Phone1 = $_POST['Phone1'];  
            $products = $_POST['products'];  
            $Size1 = $_POST['Size1'];   
            $Quantity1 = $_POST['Quantity1'];   
            $Price1 = $_POST['Price1'];
            
$update=mysqli_query($con, "UPDATE `Inventory` SET fname = '$FirstName1', lname = '$LastName1', Email='$Email1', `Phone Number` = '$Phone1', Size = '$Size1', Quantity = '$Quantity1', Price = '$Price1' WHERE Id='$id'");           
 if($update) 
                header("location: NFTadminWelcome.php");
            else 
                $msg= 'Error: '. mysqli_error($con);

}

?>

<br> 
<br>

<?php 


$result = mysqli_query($con, "SELECT `Id`,`fname`, `lname`, `Email`, `Phone Number`, `Product`, `Size`, `Quantity`, `Price` FROM `Inventory`");

echo "<table border='1'>
<tr>
<th>Id</th>
<th>First Name</th>
<th>Last Name</th> 
<th>Email</th>
<th>Phone Number</th>  
<th>Product</th>  
<th>Size</th> 
<th>Quantity</th> 
<th>Price</th> 
<th>Delete</th>  
<th>Update</th>  
</tr>";


 if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) { 
        echo "<tr>"; 
        echo "<td>{$row['Id']}</td>";
        echo "<td>{$row['fname']}</td>";
        echo "<td>{$row['lname']}</td>"; 
        echo "<td>{$row['Email']}</td>";
        echo "<td>{$row['Phone Number']}</td>"; 
        echo "<td>{$row['Product']}</td>";
        echo "<td>{$row['Size']}</td>"; 
        echo "<td>{$row['Quantity']}</td>";
        echo "<td>{$row['Price']}.00</td>"; 
        echo "<td> <a href ='NFTadminWelcome.php?epr=delete&Id=".$row['Id']. "'>Delete</a> </td>"; 
        echo "<td> <a href ='NFTadminWelcome.php?epr=update&Id=" . $row['Id'] .="' >Update</a> </td>";        
        echo "</tr>";
        
     } 
       echo "</table>";
} else {
     echo "0 results";
}



?>   

<?php 

echo $msg;

?>


</div>

</body>
</html>