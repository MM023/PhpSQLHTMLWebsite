<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : EarthyBlue 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20140215

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nike Factory Town</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900|Quicksand:400,700|Questrial" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->


<style>
.error {color: #FF0000;}
</style>


</head>
<body>
<div id="header-wrapper">
  <div id="header" class="container">
    <div id="logo">
      <h1><a href="#">Nike Factory Town</a></h1>
      <div id="menu">
        <ul>
          <li><a href="NFThome.html" accesskey="1" title="">Homepage</a></li>
          <li><a href="NFTinventory.html" accesskey="2" title="">Inventory</a></li> 
          <li ><a href="NFTorder.php" accesskey="3" title="">Order Form</a></li>
          <li class="active"><a href="NFTcontact.php" accesskey="4" title="">Contact Us</a></li> 
          <li><a href="NFTadminlogin.php" accesskey="5" title="">Admin Login</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<div id="page-wrapper">
  <div id="welcome" class="container">
    <div class="title">
      <h2>Contact Us</h2>
    </div>
    
    <center>

<form name="contactform" method="post" action="send_form_email.php">
 
<table width="450px">
 
<tr>
 
 <td valign="top">
 
  <label for="first_name">First Name <span class="error">*</span></label>
 
 </td>
 
 <td valign="top">
 
  <input  type="text" name="first_name" maxlength="50" size="30">
 
 </td>
 
</tr>
 
<tr>
 
 <td valign="top"">
 
  <label for="last_name">Last Name <span class="error">*</span></label>
 
 </td>
 
 <td valign="top">
 
  <input  type="text" name="last_name" maxlength="50" size="30">
 
 </td>
 
</tr>
 
<tr>
 
 <td valign="top">
 
  <label for="email">Email Address <span class="error">*</span></label>
 
 </td>
 
 <td valign="top">
 
  <input  type="text" name="email" maxlength="80" size="30">
 
 </td>
 
</tr>
 
<tr>
 
 <td valign="top">
 
  <label for="telephone">Telephone Number</label>
 
 </td>
 
 <td valign="top">
 
  <input  type="text" name="telephone" maxlength="30" size="30">
 
 </td>
 
</tr>
 
<tr>
 
 <td valign="top">
 
  <label for="comments">Comments <span class="error">*</span></label>
 
 </td>
 
 <td valign="top">
 
  <textarea  name="comments" maxlength="1000" cols="25" rows="6"></textarea>
 
 </td>
 
</tr>
 
<tr>
 
 <td colspan="2" style="text-align:center">
 
  <input type="submit" value="Submit"> 
 
 </td>
 
</tr>
 
</table>
 
</form>

    </center>

<br>
<br>

    
  </div> 
</div>  

<div id="copyright" class="container">
  <p>This website is fictional and is just for fun. |  Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>

</div>

</body>
</html>